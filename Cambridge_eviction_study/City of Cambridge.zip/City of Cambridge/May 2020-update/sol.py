import pandas as pd
import numpy as np
import csv

# code to read csv
# to run, just type process_dict() in Python Shell
def process_dict():
    dictionary = {}
    property_data = pd.read_csv("Cambridge_Property_Database.csv", encoding = "ISO-8859-1")
    address = property_data["Address"]
    for add in address:
        add = add.replace("\n", "")
        arr = add.split("(")
        addre = arr[0]
        latlong = arr[1].replace(")", "")
        dictionary[addre] = latlong

    with open("dictionary.csv", "w", newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["Address", "Latlong"])
        for key in dictionary.keys():
            writer.writerow([key, dictionary[key]])
    f.close()

# code to classify affordable housing
# to run, just type match_affordable() in Python Shell
def match_affordable():
    eviction_data = pd.read_csv("eviction_latlng.csv")
    affordable = pd.read_csv("affordable.csv")
    mydict = affordable["plaintiff"].unique()
    afford_li = []
    count = 0
    for i in eviction_data["plaintiff"]:
        if i in mydict:
            afford_li.append(1)
            count+=1
        else:
            afford_li.append(0)
    eviction_data["affordable"] = afford_li
    print("Total affordable is ", count)
    return eviction_data

# code to classify rental housing
# to run, just type match_rental() in Python Shell
def match_rental():
    eviction_data = pd.read_csv("eviction_affordable.csv")
    rental = pd.read_csv("rental.csv")
    mydict = rental["plaintiff"].unique()
    rental_li = []
    count = 0
    for i in eviction_data["plaintiff"]:
        if i in mydict:
            rental_li.append(2)
            count+=1
        else:
            rental_li.append(0)
    eviction_data["rental"] = rental_li
    print("Total Rental is ", count)
    return eviction_data

# code to classify affordable housing
# to run, just type match_type() in Python Shell
def match_type():
    eviction_data = pd.read_csv("eviction_type.csv")
    
    eviction_data["type"] = eviction_data["affordable"] + eviction_data["rental"]
    eviction_data.to_csv("eviction_type.csv")

from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans

import pandas as pd
import numpy as np

# code to normalize data fields
def norm(data):
    max = np.max(data)
    min = np.min(data)
    return (data-min)/(max-min)

labels = ['latitude', 'longitude', 'Value']

data = pd.read_csv('value_latlng.csv')
cluster_data = data[labels]

cluster_data['Value'] = np.array(cluster_data['Value'])
clusters = KMeans(n_clusters=5, random_state=0).fit(cluster_data).predict(cluster_data)

data['label'] = clusters
data.to_csv('affordable_units_cluster.csv')


# code to convert address to geo-coordinates
# this takes long, around 2s for each record.
import geocoder
data = pd.read_csv("Cambridge_House_Value.csv", encoding = "ISO-8859-1")
data['latitude'] = ''
data['longitude'] = ''

def find_addr(addr):
    g = geocoder.arcgis(addr)
    return g.lat, g.lng

for i in range(15001, len(data)):
    print(i)
    addr_str = data.iloc[i]['Address'] + ", " + data.iloc[i]['City'] + ", "  + data.iloc[i]['State'] + " " + str(data.iloc[i]['Zip'])
    data.loc[i,['latitude']], data.loc[i,['longitude']] = find_addr(addr_str)



